F_NV_HD_1 1 NonValidator.cpp
F_SR_HD_1 1 StdXMLReader.cpp
F_SR_HD_2 2 StdXMLReader.cpp
F_XEL_HD_1 1 XMLElement.cpp
F_XER_HD_1 1 XMLEntityResolver.cpp
F_XE_HD_1 1 XMLException.cpp
F_XE_HD_2 2 XMLException.cpp
