 

package de.susebox.jtopas;

 
 
 

 

public interface Plugin {
  
   

  public void setTokenizer(PluginTokenizer tokenizer);
}
