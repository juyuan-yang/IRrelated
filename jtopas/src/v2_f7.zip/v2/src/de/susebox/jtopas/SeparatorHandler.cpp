 

package de.susebox.jtopas;

 
 
 

 

public interface SeparatorHandler extends Plugin {
  
   

  public boolean isSeparator(char testChar);
}
